# Cómo sacar el APK de Duelo de Arena (sin instalar nada)

El proyecto ya está listo. GitHub (gratis) lo compila en la nube y te da el archivo `app-debug.apk`.

## Desde el móvil, con GitHub
1. Entra en https://github.com, crea una cuenta gratis si no la tienes y toca **+ → New repository**. Ponle un nombre, por ejemplo `duelo-de-arena`, y pulsa **Create repository**.
2. En el repositorio: **Add file → Upload files**. Sube `duelo-de-arena-android.zip` **sin descomprimir** y pulsa **Commit changes**.
3. **Add file → Create new file**. En el nombre escribe exactamente `.github/workflows/apk.yml` y pega dentro el contenido del archivo `apk.yml`. Pulsa **Commit changes**.
4. Abre la pestaña **Actions**. Verás "Compilar APK" ejecutándose (tarda de 5 a 10 minutos). Si no arranca solo, entra en él y pulsa **Run workflow**.
5. Cuando salga el círculo verde, abre esa ejecución y baja hasta **Artifacts**. Descarga `DueloDeArena-APK`, descomprímelo y obtendrás `app-debug.apk`.
6. Ábrelo en el móvil e instálalo. Android te pedirá permiso para "instalar apps de orígenes desconocidos".

## Desde un ordenador, con Android Studio
Descomprime el zip, abre la carpeta con Android Studio y elige **Build → Build Bundle(s) / APK(s) → Build APK(s)**. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Cosas a tener en cuenta
- El APK funciona sin conexión.
- La partida se guarda en el propio móvil. El guardado en la nube solo funciona dentro de Claude. Para pasar la partida entre el APK y Claude usa el botón **Guardar / cargar** del menú.
- Es un APK de pruebas (firmado con la clave de depuración). Sirve para instalar en tu móvil. Para publicarlo en Play Store habría que firmarlo con tu propia clave.
- El juego está en `app/src/main/assets/www/`. Si cambias algo ahí, vuelve a compilar.
